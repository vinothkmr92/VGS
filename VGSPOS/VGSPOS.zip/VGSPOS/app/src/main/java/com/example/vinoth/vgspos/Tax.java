package com.example.vinoth.vgspos;

public class Tax {
    private int Tax_Id;
    private double Tax_Value;

    public int getTax_Id() {
        return Tax_Id;
    }

    public void setTax_Id(int tax_Id) {
        Tax_Id = tax_Id;
    }

    public double getTax_Value() {
        return Tax_Value;
    }

    public void setTax_Value(double tax_Value) {
        Tax_Value = tax_Value;
    }
}
